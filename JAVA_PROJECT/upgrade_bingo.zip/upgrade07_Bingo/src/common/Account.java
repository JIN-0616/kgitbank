package common;

import java.io.Serializable;

public class Account implements Serializable{	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	String nick;
	String pass;
	int win;
	int lose;
	
	public Account(String nick, String pass) {
		this.nick=nick;
		this.pass=pass;
		win = lose = 0;
	}
	
	@Override
	public String toString() {
		return getNick() +" : "+win+"�� "+lose+"��";
	}

	public String getNick() {
		return nick;
	}

	public void setNick(String nick) {
		this.nick = nick;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public int getWin() {
		return win;
	}

	public void setWin(int win) {
		this.win = win;
	}

	public int getLose() {
		return lose;
	}

	public void setLose(int lose) {
		this.lose = lose;
	}

	
	
}
