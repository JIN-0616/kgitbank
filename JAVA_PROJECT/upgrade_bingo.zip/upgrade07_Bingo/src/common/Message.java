package common;

import java.io.Serializable;

public class Message implements Serializable{
	String talker;
	String message;
	long time;		// System.currentTimeMilliis()�� ���
	@Override
	public String toString() {
		return getTalker() +" : "+getMessage();
	}
	public Message(String talker, String message, long time) {
		this.talker = talker;
		this.message = message;
		this.time = time;
	}
	public String getTalker() {
		return talker;
	}
	public void setTalker(String talker) {
		this.talker = talker;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public long getTime() {
		return time;
	}
	public void setTime(long time) {
		this.time = time;
	}
	
}
