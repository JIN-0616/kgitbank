package client;

import javax.swing.JFrame;

import client.handler.AuthPassHandler;
import client.handler.ChatActionHandler;
import client.handler.ExitActionHandler;
import client.handler.JoinHandler;
import client.handler.radioButtonHandler;
import client.panel.LoungePanel;
import client.panel.WelcomePanel;

public class ClientUI extends JFrame {
	public ClientNetWorker net;
	public WelcomePanel pnWelcome;
	public LoungePanel pnLounge;
	
	public ClientUI() {
		net = new ClientNetWorker("127.0.0.1", this);
		setUIcomponent();
		addListeners();
	}

	//action �ٿ�����, ��ü ��������
	private void addListeners() {
		pnWelcome.pfAuthPass.addActionListener(new AuthPassHandler(this));
		pnWelcome.btJoin.addActionListener(new JoinHandler(this));
		pnWelcome.rbtAgree.addItemListener(new radioButtonHandler(this));
		pnWelcome.rbtDisagree.addItemListener(new radioButtonHandler(this));		
		pnLounge.btExit.addActionListener(new ExitActionHandler(this));
		pnLounge.tfChat.addActionListener(new ChatActionHandler(this));
	}


	private void setUIcomponent() {
		setTitle("BINGO,BINGO");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		setSize(500, 375);
		int rand = (int)(Math.random()*8) *30;
		setLocation(300 + rand, 200+ rand);
		pnWelcome = new WelcomePanel();
		pnLounge = new LoungePanel();
		pnWelcome.btJoin.setEnabled(false);
		setContentPane(pnWelcome);
	}
}
