package client;

public class ClientStart {
	public static void main(String[] args) {
		ClientUI ui = new ClientUI();
		ui.setVisible(true);
		
		
	}
}
