package client;

import javax.swing.JFrame;

public class BankClientMain {
	public static void main(String[] args) {
		JFrame f = new BankClientUI();
		f.setVisible(true);
	}
}
