package model;

public class Soldier {
	String name;
	int age;
	
	public Soldier(String n, int a) {
		name = n;
		age = a;
	
	}
	
}
