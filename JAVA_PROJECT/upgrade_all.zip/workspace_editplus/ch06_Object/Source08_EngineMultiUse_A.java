class Source08_EngineMultiUse_A {
	public static void main(String[] args)	{
		UpDownEngine user = new UpDownEngine();
		UpDownEngine com = new UpDownEngine();
		user.start();
		com.start();

	}
}
