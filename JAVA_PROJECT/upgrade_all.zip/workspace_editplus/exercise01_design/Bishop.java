class Bishop extends Piece {
	Bishop(int x, int y, boolean flag){
		super(x,y,flag);
	}
	String shape(){
		return "��";
	}
	boolean cheakMove(int dx, int dy){
		

	}
}
