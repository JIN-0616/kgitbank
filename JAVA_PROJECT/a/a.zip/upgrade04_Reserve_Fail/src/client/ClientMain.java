package client;

public class ClientMain {
	public static void main(String[] args) {
		new ClientUI("192.168.10.27").setVisible(true);
	}
}


