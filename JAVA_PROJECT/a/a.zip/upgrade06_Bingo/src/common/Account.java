package common;

public class Account {
	String nick;
	String pass;
	int win;
	int lose;
	
	public Account(String nick, String pass) {
		this.nick = nick;
		this.pass = pass;
		win = lose = 0;
	}
}




















