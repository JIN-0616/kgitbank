import javax.swing.JFrame;

import ui.GolfFrame;
import ui.HotelFrame;
import ui.IndiaFrame;

public class Source04_GraphicUI_A {
	public static void main(String[] args) {
		JFrame f = new IndiaFrame();
		f.setVisible(true);
	}
}
