import ui.BravoFrame;
import ui.CharlieFrame;
import ui.DeltaPanel;
import ui.EcoFrame;

public class Source03_GraphicUI {
	public static void main(String[] args) {
	//	BravoFrame bf = new BravoFrame();
	//	bf.setVisible(true);
		
	//	CharlieFrame cf = new CharlieFrame();
	//	cf.setVisible(true);
		
		EcoFrame gf  = new EcoFrame();
		gf.setVisible(true);
	}
}
