
public class Hero {
	String name;
	int type;
	boolean special;
	
	public Hero(String n, int t, boolean s) {
		name = n;
		type = t;
		special = s;
	}
}
