package etc;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class UsefulLocation extends JFrame {

}
