package client;

public class ClientMain {
	public static void main(String[] args) {
		new ClientUI("127.0.0.1").setVisible(true);
	}
}
