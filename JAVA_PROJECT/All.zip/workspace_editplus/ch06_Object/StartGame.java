class StartGame {
	public static void main(String[] args)	{
		

	}
}
