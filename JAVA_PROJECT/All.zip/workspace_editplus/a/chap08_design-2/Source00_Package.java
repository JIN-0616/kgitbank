import java.awt.Rectangle;

class Source00_Package {
	public static void main(String[] args) 	{
		java.awt.Rectangle r1 = new java.awt.Rectangle();

		Rectangle r2 = new Rectangle();

		design.Box b1 = new design.Box();

		b1.flag = true;
	}
}
