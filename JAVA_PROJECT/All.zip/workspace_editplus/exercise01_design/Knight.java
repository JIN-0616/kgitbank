class Knight extends Piece {
	Knight(int x, int y, boolean flag){
		super(x,y,flag);
	}
	String shape(){
		return "��";
	}
	boolean cheakMove(int dx, int dy){
		

	}
}

