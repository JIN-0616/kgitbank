
public class Source01_Test {
	public static void main(String[] args) {
		System.out.println("developed by Eclipse IDE");
	//	System.console().readLine(); ����
	}

}
