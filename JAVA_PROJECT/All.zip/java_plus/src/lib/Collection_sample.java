package lib;

public class Collection_sample {

}
