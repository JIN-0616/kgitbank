package client;

public class ClientMain {
	public static void main(String[] args) {
		new ClientUI().setVisible(true);
	}
}
